/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AgriCategory = 
  | 'crop_conditions'
  | 'market_trends'
  | 'weather_risks'
  | 'pest_disease'
  | 'supply_chain'
  | 'opportunities';

export type RiskLevel = 'low' | 'moderate' | 'high' | 'critical';

export interface KeywordRule {
  keyword: string;
  category: AgriCategory;
  weight: number; // 1 to 5
  sentiment: 'positive' | 'negative' | 'neutral';
  defaultImpact: number; // 1 to 5
  defaultLikelihood: number; // 1 to 5
  description?: string;
}

export interface MatchedKeyword {
  keyword: string;
  category: AgriCategory;
  count: number;
  weight: number;
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: number;
  likelihood: number;
  matchedSentences: string[];
}

export interface CommodityMention {
  commodity: string;
  count: number;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  contexts: string[];
}

export interface RegionMention {
  region: string;
  count: number;
}

export interface RiskMatrixItem {
  id: string;
  title: string;
  category: AgriCategory;
  likelihood: number; // 1 to 5
  impact: number;     // 1 to 5
  riskScore: number;  // likelihood * impact (1 to 25)
  level: RiskLevel;
  evidence: string;
  mitigation: string;
}

export interface Recommendation {
  id: string;
  target: 'farmer' | 'cooperative' | 'trader' | 'policymaker';
  title: string;
  action: string;
  rationale: string;
  priority: 'high' | 'medium' | 'low';
  category: AgriCategory;
}

export interface AgriKPIs {
  yieldSentimentIndex: number;      // 0 - 100 (50 is neutral, >50 positive, <50 negative)
  marketPriceMomentum: number;      // -100 to +100 (-100 sharp decline, 0 stable, +100 sharp spike)
  opportunityIndex: number;         // 0 - 100
  inputCostPressureIndex: number;   // 0 - 100 (higher = worse cost inflation)
  productionHealthScore: number;    // 0 - 100
}

export interface AgriKRIs {
  compositeRiskScore: number;       // 0 - 100
  compositeRiskLevel: RiskLevel;
  weatherVulnerabilityKRI: number;  // 0 - 100
  biosecurityHazardKRI: number;     // 0 - 100
  supplyChainFrictionKRI: number;   // 0 - 100
  marketVolatilityKRI: number;      // 0 - 100
}

export interface CategoryBreakdownScore {
  category: AgriCategory;
  label: string;
  count: number;
  intensity: number; // 0 - 100
  sentimentScore: number; // -1 to +1
}

export interface AnalysisResult {
  id: string;
  timestamp: string;
  sourceTitle: string;
  sourceType: string;
  wordCount: number;
  sentenceCount: number;
  kpis: AgriKPIs;
  kris: AgriKRIs;
  categoryBreakdown: CategoryBreakdownScore[];
  matchedKeywords: MatchedKeyword[];
  commodities: CommodityMention[];
  regions: RegionMention[];
  riskMatrix: RiskMatrixItem[];
  recommendations: Recommendation[];
  rawText: string;
  executiveSummary: string;
}

export interface NewsSample {
  id: string;
  title: string;
  source: string;
  categoryFocus: string;
  date: string;
  region: string;
  text: string;
  description: string;
}
