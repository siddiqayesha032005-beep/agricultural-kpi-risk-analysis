/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from 'react';
import { 
  Sparkles, 
  Upload, 
  Trash2, 
  Clipboard, 
  FileText, 
  Compass,
  ArrowRight
} from 'lucide-react';
import { SAMPLE_ARTICLES } from '../data/sampleArticles';

interface TextInputSectionProps {
  text: string;
  onChangeText: (val: string) => void;
  title: string;
  onChangeTitle: (val: string) => void;
  sourceType: string;
  onChangeSourceType: (val: string) => void;
  selectedSampleId: string;
  onSelectSample: (sampleId: string) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
}

export const TextInputSection: React.FC<TextInputSectionProps> = ({
  text,
  onChangeText,
  title,
  onChangeTitle,
  sourceType,
  onChangeSourceType,
  selectedSampleId,
  onSelectSample,
  onAnalyze,
  isAnalyzing
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  const charCount = text.length;

  const handlePaste = async () => {
    try {
      const clip = await navigator.clipboard.readText();
      if (clip) {
        onChangeText(clip);
      }
    } catch {
      // Fallback or ignore if blocked
    }
  };

  const handleClear = () => {
    onChangeText('');
    onChangeTitle('Custom Agricultural Report');
    onSelectSample('custom');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        onChangeText(content);
        onChangeTitle(file.name.replace(/\.[^/.]+$/, ''));
        onSelectSample('custom');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <section id="input-hub" className="bg-white border-b border-slate-200 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 tracking-wide uppercase">
              <span>Agricultural News & Intelligence Ingestion</span>
              <span aria-hidden="true">·</span>
              <span>Rule-Based NLP Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1 tracking-tight">
              Transform Agricultural Text into KPIs & Risk Indicators
            </h1>
            <p className="text-sm text-slate-600 mt-1 max-w-3xl">
              Paste news articles, crop advisories, market feeds, or government publications. The system scans predefined agricultural rule sets to compute quantitative risk scores, commodity momentum, and field recommendations.
            </p>
          </div>

          {/* Quick Stats or status */}
          <div className="flex items-center gap-3 text-xs text-slate-500 font-mono shrink-0">
            <span>Words: <strong className="text-slate-800 font-semibold">{wordCount}</strong></span>
            <span aria-hidden="true">·</span>
            <span>Chars: <strong className="text-slate-800 font-semibold">{charCount}</strong></span>
          </div>
        </div>

        {/* Sample Selection Strip */}
        <div className="mb-4">
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-emerald-600" />
              Load Real-World Scenarios
            </span>
            <span className="text-xs text-slate-500">Click to auto-populate news scenario</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
            {SAMPLE_ARTICLES.map((sample) => {
              const isSelected = selectedSampleId === sample.id;
              return (
                <button
                  key={sample.id}
                  onClick={() => onSelectSample(sample.id)}
                  className={`text-left p-3 rounded-lg border text-xs transition-all ${
                    isSelected
                      ? 'bg-emerald-50/70 border-emerald-500 ring-1 ring-emerald-500 text-slate-900 shadow-xs'
                      : 'bg-slate-50/70 border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300'
                  }`}
                >
                  <div className="font-semibold text-slate-900 truncate mb-1">
                    {sample.title.split(':')[0]}
                  </div>
                  <div className="text-slate-500 text-[11px] line-clamp-2">
                    {sample.categoryFocus} · {sample.region.split('(')[0]}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Form Fields */}
        <div className="bg-slate-50/70 rounded-xl border border-slate-200 p-4 sm:p-5">
          {/* Metadata Controls Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
            <div className="sm:col-span-2">
              <label htmlFor="report-title" className="block text-xs font-semibold text-slate-700 mb-1">
                Document / Article Title
              </label>
              <input
                id="report-title"
                type="text"
                value={title}
                onChange={(e) => onChangeTitle(e.target.value)}
                placeholder="e.g. Drought Alert in Black Sea Grain Corridor"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
              />
            </div>

            <div>
              <label htmlFor="source-type" className="block text-xs font-semibold text-slate-700 mb-1">
                Source Classification
              </label>
              <select
                id="source-type"
                value={sourceType}
                onChange={(e) => onChangeSourceType(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
              >
                <option value="News Wire & Media">News Wire & Media (Reuters, Bloomberg, AP)</option>
                <option value="Government & Ministry">Government & Ministry (USDA, FAO, CDFA)</option>
                <option value="Agronomic Extension">Agronomic Extension & University Lab</option>
                <option value="Commodity Exchange">Commodity Exchange & Brokerage Report</option>
                <option value="Grower Forum / Reddit">Grower Forum / Social Intelligence</option>
              </select>
            </div>
          </div>

          {/* Text Area */}
          <div className="relative">
            <label htmlFor="news-text" className="block text-xs font-semibold text-slate-700 mb-1">
              Agricultural News Text & Field Notes
            </label>
            <textarea
              id="news-text"
              rows={8}
              value={text}
              onChange={(e) => {
                onChangeText(e.target.value);
                if (selectedSampleId !== 'custom') onSelectSample('custom');
              }}
              placeholder="Paste agricultural news, market commentary, weather alerts, or pest surveillance text here..."
              className="w-full p-3.5 text-sm font-sans leading-relaxed bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors resize-y"
            />
          </div>

          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 mt-3 pt-3 border-t border-slate-200/80">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePaste}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-md transition-colors flex items-center gap-1.5"
                title="Paste text from clipboard"
              >
                <Clipboard className="w-3.5 h-3.5" />
                <span>Paste</span>
              </button>

              <label className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload File</span>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".txt,.md,.csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              {text && (
                <button
                  type="button"
                  onClick={handleClear}
                  className="px-3 py-1.5 text-xs font-medium text-rose-700 bg-white hover:bg-rose-50 border border-slate-200 rounded-md transition-colors flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear</span>
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={onAnalyze}
              disabled={isAnalyzing || !text.trim()}
              className="px-5 py-2 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm transition-all flex items-center gap-2 shrink-0"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isAnalyzing ? 'Extracting Indicators...' : 'Run Agricultural Intelligence'}</span>
              <ArrowRight className="w-4 h-4 ml-0.5" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
