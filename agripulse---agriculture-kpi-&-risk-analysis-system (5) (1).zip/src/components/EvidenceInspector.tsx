/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Tag, 
  Filter, 
  Eye, 
  Copy, 
  Check 
} from 'lucide-react';
import { MatchedKeyword, AgriCategory } from '../types/agriculture';
import { CATEGORY_META } from '../data/agriRules';

interface EvidenceInspectorProps {
  rawText: string;
  matchedKeywords: MatchedKeyword[];
}

export const EvidenceInspector: React.FC<EvidenceInspectorProps> = ({
  rawText,
  matchedKeywords
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [highlightKeyword, setHighlightKeyword] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  const filteredKeywords = matchedKeywords.filter(k => {
    const matchesCat = selectedCategory === 'all' || k.category === selectedCategory;
    const matchesSearch = k.keyword.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(rawText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Render text with highlight
  const renderHighlightedText = () => {
    if (!highlightKeyword) {
      return <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-line">{rawText}</p>;
    }

    const regex = new RegExp(`(${highlightKeyword})`, 'gi');
    const parts = rawText.split(regex);

    return (
      <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-line">
        {parts.map((part, i) => {
          if (part.toLowerCase() === highlightKeyword.toLowerCase()) {
            return (
              <mark key={i} className="bg-amber-200 text-slate-900 font-bold px-1 rounded">
                {part}
              </mark>
            );
          }
          return <span key={i}>{part}</span>;
        })}
      </p>
    );
  };

  return (
    <section className="py-8 bg-slate-50/50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <div className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              Rule Matching & Text Verification
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
              Extracted Agricultural Keywords & Source Evidence
            </h2>
          </div>
          <div className="text-xs text-slate-500">
            Click any keyword below to highlight its occurrence in the original text
          </div>
        </div>

        {/* 2-Column Split: Extracted Keywords Grid on Left, Highlighted Text on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left: Matched Keywords List with Filters */}
          <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-emerald-600" />
                Detected Indicators ({matchedKeywords.length})
              </span>
              {highlightKeyword && (
                <button
                  onClick={() => setHighlightKeyword('')}
                  className="text-xs text-emerald-700 hover:underline font-medium"
                >
                  Clear Highlight
                </button>
              )}
            </div>

            {/* Category filter pills / segmented buttons */}
            <div className="flex flex-wrap gap-1.5 mb-3">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
                  selectedCategory === 'all'
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All
              </button>
              {(Object.keys(CATEGORY_META) as AgriCategory[]).map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
                    selectedCategory === cat
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {CATEGORY_META[cat].label.split(' ')[0]}
                </button>
              ))}
            </div>

            {/* Keyword Search */}
            <div className="relative mb-3">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter keywords..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            {/* Keyword Pills List */}
            <div className="max-h-80 overflow-y-auto space-y-1.5 pr-1">
              {filteredKeywords.length > 0 ? (
                filteredKeywords.map((k) => {
                  const isHighlighted = highlightKeyword.toLowerCase() === k.keyword.toLowerCase();
                  const meta = CATEGORY_META[k.category];
                  return (
                    <button
                      key={k.keyword}
                      onClick={() => setHighlightKeyword(isHighlighted ? '' : k.keyword)}
                      className={`w-full text-left p-2 rounded-lg border text-xs flex items-center justify-between transition-all ${
                        isHighlighted
                          ? 'bg-amber-100/90 border-amber-400 text-slate-900 shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate pr-2">
                        <span 
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{ backgroundColor: meta?.color || '#059669' }}
                        />
                        <span className="font-semibold truncate capitalize">
                          {k.keyword}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-slate-500 font-mono text-[11px] shrink-0">
                        <span>×{k.count}</span>
                        <span aria-hidden="true">·</span>
                        <span>Wt: {k.weight}</span>
                      </div>
                    </button>
                  );
                })
              ) : (
                <div className="text-center py-6 text-xs text-slate-500">
                  No matching keywords found for this filter.
                </div>
              )}
            </div>
          </div>

          {/* Right: Full Document Text with Highlight */}
          <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
                <FileText className="w-3.5 h-3.5 text-slate-500" />
                <span>Source Text Inspection</span>
              </div>

              <div className="flex items-center gap-2">
                {highlightKeyword && (
                  <span className="text-xs text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                    Highlighting: <strong>{highlightKeyword}</strong>
                  </span>
                )}
                <button
                  onClick={handleCopy}
                  className="px-2.5 py-1 text-xs text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded flex items-center gap-1 transition-colors"
                  title="Copy full text"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            <div className="max-h-[380px] overflow-y-auto pr-2">
              {renderHighlightedText()}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
