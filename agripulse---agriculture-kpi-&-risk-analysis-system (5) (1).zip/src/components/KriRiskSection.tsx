/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  ShieldAlert, 
  CloudRain, 
  Bug, 
  Truck, 
  Scale, 
  AlertTriangle,
  Info
} from 'lucide-react';
import { AgriKRIs, RiskLevel } from '../types/agriculture';

interface KriRiskSectionProps {
  kris: AgriKRIs;
}

export const KriRiskSection: React.FC<KriRiskSectionProps> = ({ kris }) => {
  const getRiskColor = (level: RiskLevel) => {
    switch (level) {
      case 'critical':
        return {
          bg: 'bg-rose-50',
          border: 'border-rose-200',
          text: 'text-rose-700',
          accent: '#dc2626',
          badge: 'CRITICAL HAZARD'
        };
      case 'high':
        return {
          bg: 'bg-orange-50',
          border: 'border-orange-200',
          text: 'text-orange-700',
          accent: '#ea580c',
          badge: 'HIGH ALERT'
        };
      case 'moderate':
        return {
          bg: 'bg-amber-50',
          border: 'border-amber-200',
          text: 'text-amber-700',
          accent: '#d97706',
          badge: 'MODERATE RISK'
        };
      default:
        return {
          bg: 'bg-emerald-50',
          border: 'border-emerald-200',
          text: 'text-emerald-700',
          accent: '#059669',
          badge: 'LOW / STABLE'
        };
    }
  };

  const riskTheme = getRiskColor(kris.compositeRiskLevel);

  // SVG circular gauge calculation
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (kris.compositeRiskScore / 100) * circumference;

  const subKris = [
    {
      id: 'weather',
      label: 'Weather Vulnerability KRI',
      sublabel: 'Drought, frost, excessive rain, heat stress',
      score: kris.weatherVulnerabilityKRI,
      weight: '30% weight',
      icon: CloudRain,
      color: 'bg-amber-500'
    },
    {
      id: 'biosecurity',
      label: 'Biosecurity & Pest Hazard KRI',
      sublabel: 'Bacterial blight, rusts, armyworms, locusts',
      score: kris.biosecurityHazardKRI,
      weight: '25% weight',
      icon: Bug,
      color: 'bg-rose-500'
    },
    {
      id: 'supply_chain',
      label: 'Supply Chain Friction KRI',
      sublabel: 'Fertilizer shortages, freight bottlenecks, ports',
      score: kris.supplyChainFrictionKRI,
      weight: '25% weight',
      icon: Truck,
      color: 'bg-purple-600'
    },
    {
      id: 'market_volatility',
      label: 'Market & Regulatory Volatility KRI',
      sublabel: 'Export bans, tariff policy, price collapse',
      score: kris.marketVolatilityKRI,
      weight: '20% weight',
      icon: Scale,
      color: 'bg-blue-600'
    }
  ];

  return (
    <section id="kri-section" className="py-8 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <div className="text-xs font-semibold text-rose-700 uppercase tracking-wider">
              Vulnerability Assessment
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
              Key Risk Indicators (KRIs) & Threat Exposure
            </h2>
          </div>
          <div className="text-xs text-slate-500">
            Multi-factor weighted index of biological, climatic, and logistics hazards
          </div>
        </div>

        {/* 2-Column Split: Composite Gauge on Left, 4 Sub-KRIs on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Left: Composite Agri-Risk Gauge Card */}
          <div className={`lg:col-span-4 rounded-xl border ${riskTheme.border} ${riskTheme.bg} p-6 flex flex-col justify-between`}>
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  Composite Agri-Risk Index
                </span>
                <span className={`text-xs font-bold ${riskTheme.text}`}>
                  {riskTheme.badge}
                </span>
              </div>

              {/* Gauge Graphic */}
              <div className="relative w-44 h-44 mx-auto my-4 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
                  {/* Track Circle */}
                  <circle
                    cx="80"
                    cy="80"
                    r={radius}
                    fill="none"
                    stroke="#e2e8f0"
                    strokeWidth="12"
                  />
                  {/* Progress Circle */}
                  <circle
                    cx="80"
                    cy="80"
                    r={radius}
                    fill="none"
                    stroke={riskTheme.accent}
                    strokeWidth="12"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    className="transition-all duration-1000 ease-out"
                  />
                </svg>
                {/* Center Score Display */}
                <div className="absolute flex flex-col items-center justify-center text-center">
                  <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums leading-none">
                    {kris.compositeRiskScore}
                  </span>
                  <span className="text-xs font-medium text-slate-500 mt-1">out of 100</span>
                  <span className={`text-xs font-bold mt-0.5 ${riskTheme.text} uppercase`}>
                    {kris.compositeRiskLevel}
                  </span>
                </div>
              </div>
            </div>

            {/* Assessment summary text */}
            <div className="text-xs text-slate-700 bg-white/80 rounded-lg p-3 border border-slate-200/80">
              <div className="font-semibold text-slate-900 mb-0.5 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                Operational Exposure Profile
              </div>
              <p className="leading-relaxed">
                {kris.compositeRiskLevel === 'critical'
                  ? 'Severe compound risks detected across weather and biological factors. Immediate mitigation and asset safeguarding recommended.'
                  : kris.compositeRiskLevel === 'high'
                  ? 'High risk exposure identified. Supply chain or climatic bottlenecks require active hedging and biosecurity precautions.'
                  : kris.compositeRiskLevel === 'moderate'
                  ? 'Moderate agricultural volatility. Conditions are manageable through standard IPM scouting and forward contracts.'
                  : 'Favorable operational profile. No acute catastrophic indicators found in current intelligence data.'}
              </p>
            </div>
          </div>

          {/* Right: 4 Sub-KRIs Card */}
          <div className="lg:col-span-8 bg-slate-50/70 rounded-xl border border-slate-200 p-6 flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Threat Vector Sub-Scores
              </span>
              <div className="flex items-center gap-3 text-xs text-slate-500">
                <span>0-30: Low</span>
                <span aria-hidden="true">·</span>
                <span>31-60: Moderate</span>
                <span aria-hidden="true">·</span>
                <span>61-80: High</span>
                <span aria-hidden="true">·</span>
                <span>81-100: Critical</span>
              </div>
            </div>

            {/* List of 4 sub-KRIs */}
            <div className="space-y-4">
              {subKris.map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.id} className="bg-white rounded-lg border border-slate-200 p-3.5">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-md bg-slate-100 flex items-center justify-center text-slate-700 shrink-0">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-slate-900">
                            {item.label}
                          </div>
                          <div className="text-xs text-slate-500">
                            {item.sublabel}
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-lg font-extrabold text-slate-900 font-mono tabular-nums leading-none">
                          {item.score}
                          <span className="text-xs font-normal text-slate-500">/100</span>
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {item.weight}
                        </div>
                      </div>
                    </div>

                    {/* Progress track */}
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-700 ${item.color}`}
                        style={{ width: `${item.score}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom calculation note */}
            <div className="flex items-center gap-2 mt-4 text-xs text-slate-500 pt-3 border-t border-slate-200">
              <Info className="w-4 h-4 text-slate-400 shrink-0" />
              <span>
                Calculated dynamically via agricultural keyword frequency, severity weighting, and sentence context rules.
              </span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
