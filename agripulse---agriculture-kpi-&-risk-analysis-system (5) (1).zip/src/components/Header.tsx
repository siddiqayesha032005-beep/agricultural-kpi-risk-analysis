/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Sprout, 
  BookOpen, 
  FileText, 
  Settings2, 
  History, 
  Download
} from 'lucide-react';

interface HeaderProps {
  onOpenRules: () => void;
  onOpenHistory: () => void;
  onOpenExport: () => void;
  hasResult: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenRules,
  onOpenHistory,
  onOpenExport,
  hasResult
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-xs">
              <Sprout className="w-5 h-5" />
            </div>
            <a href="/" className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
              AgriPulse <span className="font-medium text-emerald-600 text-sm">Intelligence</span>
            </a>
          </div>

          {/* Zone 2: Clean single-line navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a href="#input-hub" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">
              News Ingestion
            </a>
            <a href="#kpi-section" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">
              Agricultural KPIs
            </a>
            <a href="#kri-section" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">
              Risk Indicators (KRIs)
            </a>
            <a href="#risk-matrix-section" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">
              Risk Matrix
            </a>
            <a href="#recommendations-section" className="hover:text-emerald-700 transition-colors whitespace-nowrap shrink-0">
              Advisories
            </a>
          </nav>

          {/* Zone 3: Functional action controls */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onOpenRules}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap"
              title="Inspect or customize rule keywords and weights"
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span>Rulebook</span>
            </button>

            <button
              onClick={onOpenHistory}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap"
              title="View previously analyzed reports"
            >
              <History className="w-3.5 h-3.5" />
              <span>History</span>
            </button>

            {hasResult && (
              <button
                onClick={onOpenExport}
                className="px-3.5 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors shadow-xs flex items-center gap-1.5 whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Report</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
