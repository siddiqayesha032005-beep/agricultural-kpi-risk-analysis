/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  RotateCcw, 
  Settings2, 
  Search, 
  Tag, 
  Check, 
  Sliders
} from 'lucide-react';
import { KeywordRule, AgriCategory } from '../types/agriculture';
import { CATEGORY_META, DEFAULT_RULES } from '../data/agriRules';

interface RuleCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  rules: KeywordRule[];
  onUpdateRules: (newRules: KeywordRule[]) => void;
  onResetRules: () => void;
}

export const RuleCustomizerModal: React.FC<RuleCustomizerModalProps> = ({
  isOpen,
  onClose,
  rules,
  onUpdateRules,
  onResetRules
}) => {
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState<string>('all');
  
  // New rule state
  const [newKeyword, setNewKeyword] = useState('');
  const [newCat, setNewCat] = useState<AgriCategory>('crop_conditions');
  const [newWeight, setNewWeight] = useState<number>(3);
  const [newSentiment, setNewSentiment] = useState<'positive' | 'negative' | 'neutral'>('negative');
  const [showAddForm, setShowAddForm] = useState(false);

  if (!isOpen) return null;

  const filteredRules = rules.filter(r => {
    const matchesCat = filterCat === 'all' || r.category === filterCat;
    const matchesSearch = r.keyword.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyword.trim()) return;

    const trimmed = newKeyword.trim().toLowerCase();
    if (rules.some(r => r.keyword.toLowerCase() === trimmed)) {
      alert('This keyword rule already exists in the dictionary.');
      return;
    }

    const created: KeywordRule = {
      keyword: trimmed,
      category: newCat,
      weight: newWeight,
      sentiment: newSentiment,
      defaultImpact: newWeight,
      defaultLikelihood: 3
    };

    onUpdateRules([created, ...rules]);
    setNewKeyword('');
    setShowAddForm(false);
  };

  const handleDeleteRule = (keyword: string) => {
    onUpdateRules(rules.filter(r => r.keyword !== keyword));
  };

  const handleWeightChange = (keyword: string, weight: number) => {
    onUpdateRules(rules.map(r => r.keyword === keyword ? { ...r, weight } : r));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-xl border border-slate-200 overflow-hidden">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Settings2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Agricultural Rulebook & Scoring Weights
              </h2>
              <p className="text-xs text-slate-500">
                Inspect keyword dictionaries, adjust threat weights (1-5), or add custom domain indicators
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onResetRules}
              className="px-2.5 py-1.5 text-xs text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1"
              title="Reset all rules to system defaults"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action & Filter Toolbar */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-1 max-w-sm">
            <div className="relative w-full">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search rule keywords..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={filterCat}
              onChange={(e) => setFilterCat(e.target.value)}
              className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">All Dimensions ({rules.length})</option>
              {(Object.keys(CATEGORY_META) as AgriCategory[]).map(c => (
                <option key={c} value={c}>{CATEGORY_META[c].label}</option>
              ))}
            </select>

            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Keyword</span>
            </button>
          </div>
        </div>

        {/* Expandable Add Rule Form */}
        {showAddForm && (
          <form onSubmit={handleAddRule} className="p-4 bg-emerald-50/60 border-b border-emerald-100 grid grid-cols-1 sm:grid-cols-5 gap-3 items-end">
            <div className="sm:col-span-2">
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                New Keyword / Phrase
              </label>
              <input
                type="text"
                required
                value={newKeyword}
                onChange={(e) => setNewKeyword(e.target.value)}
                placeholder="e.g. tar spot, floodgate open, locust"
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Category
              </label>
              <select
                value={newCat}
                onChange={(e) => setNewCat(e.target.value as AgriCategory)}
                className="w-full px-2 py-1.5 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                {(Object.keys(CATEGORY_META) as AgriCategory[]).map(c => (
                  <option key={c} value={c}>{CATEGORY_META[c].label.split(' ')[0]}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Weight (1-5)
              </label>
              <select
                value={newWeight}
                onChange={(e) => setNewWeight(Number(e.target.value))}
                className="w-full px-2 py-1.5 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value={1}>1 (Minor signal)</option>
                <option value={2}>2 (Low weight)</option>
                <option value={3}>3 (Standard)</option>
                <option value={4}>4 (High impact)</option>
                <option value={5}>5 (Critical trigger)</option>
              </select>
            </div>

            <div>
              <button
                type="submit"
                className="w-full py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-md transition-colors"
              >
                Save Rule
              </button>
            </div>
          </form>
        )}

        {/* Rules Table */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-100/80 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-4">Agricultural Keyword</th>
                  <th className="py-2.5 px-4">Thematic Dimension</th>
                  <th className="py-2.5 px-4">Sentiment</th>
                  <th className="py-2.5 px-4">Weight Factor</th>
                  <th className="py-2.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRules.map((rule) => {
                  const meta = CATEGORY_META[rule.category];
                  return (
                    <tr key={rule.keyword} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2.5 px-4 font-semibold text-slate-900">
                        {rule.keyword}
                      </td>
                      <td className="py-2.5 px-4">
                        <span 
                          className="font-medium px-2 py-0.5 rounded text-[11px]"
                          style={{
                            backgroundColor: `${meta.color}15`,
                            color: meta.color
                          }}
                        >
                          {meta.label}
                        </span>
                      </td>
                      <td className="py-2.5 px-4">
                        <span className={`font-semibold capitalize text-[11px] ${
                          rule.sentiment === 'positive' ? 'text-emerald-700' :
                          rule.sentiment === 'negative' ? 'text-rose-700' : 'text-slate-500'
                        }`}>
                          {rule.sentiment}
                        </span>
                      </td>
                      <td className="py-2.5 px-4">
                        <select
                          value={rule.weight}
                          onChange={(e) => handleWeightChange(rule.keyword, Number(e.target.value))}
                          className="px-2 py-1 text-xs border border-slate-200 rounded bg-white text-slate-800 font-mono"
                        >
                          <option value={1}>1 (Low)</option>
                          <option value={2}>2</option>
                          <option value={3}>3 (Med)</option>
                          <option value={4}>4</option>
                          <option value={5}>5 (High)</option>
                        </select>
                      </td>
                      <td className="py-2.5 px-4 text-right">
                        <button
                          onClick={() => handleDeleteRule(rule.keyword)}
                          className="text-xs text-rose-600 hover:text-rose-800 hover:underline"
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Active Rules: <strong className="text-slate-800">{rules.length}</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
          >
            Apply & Close
          </button>
        </div>

      </div>
    </div>
  );
};
