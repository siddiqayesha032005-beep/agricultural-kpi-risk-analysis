/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  X, 
  History, 
  Trash2, 
  FileText, 
  ArrowRight,
  ShieldAlert,
  Sprout
} from 'lucide-react';
import { AnalysisResult } from '../types/agriculture';

interface SavedReportsModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedReports: AnalysisResult[];
  onSelectReport: (report: AnalysisResult) => void;
  onClearHistory: () => void;
}

export const SavedReportsModal: React.FC<SavedReportsModalProps> = ({
  isOpen,
  onClose,
  savedReports,
  onSelectReport,
  onClearHistory
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-xl border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Analysis History & Saved Reports
              </h2>
              <p className="text-xs text-slate-500">
                Revisit previously analyzed news items and compare risk assessments
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {savedReports.length > 0 && (
              <button
                onClick={onClearHistory}
                className="px-2.5 py-1 text-xs text-rose-700 hover:text-rose-900 bg-rose-50 hover:bg-rose-100 rounded-md transition-colors flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {savedReports.length > 0 ? (
            savedReports.map((report) => (
              <div
                key={report.id}
                className="bg-slate-50 hover:bg-emerald-50/50 border border-slate-200 hover:border-emerald-300 rounded-xl p-4 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-[11px] text-slate-500">
                    <span>{report.timestamp}</span>
                    <span aria-hidden="true">·</span>
                    <span>{report.sourceType}</span>
                    <span aria-hidden="true">·</span>
                    <span>{report.wordCount} words</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 line-clamp-1">
                    {report.sourceTitle}
                  </h3>
                  
                  {/* Snapshot metrics */}
                  <div className="flex items-center gap-3 text-xs mt-1">
                    <span className="font-semibold text-slate-700">
                      Composite Risk: <strong className={`font-mono ${
                        report.kris.compositeRiskLevel === 'critical' ? 'text-rose-700' :
                        report.kris.compositeRiskLevel === 'high' ? 'text-orange-700' :
                        report.kris.compositeRiskLevel === 'moderate' ? 'text-amber-700' : 'text-emerald-700'
                      }`}>{report.kris.compositeRiskScore}/100</strong>
                    </span>
                    <span aria-hidden="true" className="text-slate-300">·</span>
                    <span className="font-semibold text-slate-700">
                      Yield Sentiment: <strong className="font-mono text-emerald-800">{report.kpis.yieldSentimentIndex}/100</strong>
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onSelectReport(report);
                    onClose();
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-white hover:bg-emerald-600 hover:text-white border border-emerald-300 rounded-lg transition-all flex items-center gap-1.5 shrink-0 self-end sm:self-center shadow-xs"
                >
                  <span>Load Report</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          ) : (
            <div className="text-center py-12 text-slate-500 text-xs">
              No saved analysis reports yet. Run an analysis on any news text to store results in your browser history.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Saved in LocalStorage</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
