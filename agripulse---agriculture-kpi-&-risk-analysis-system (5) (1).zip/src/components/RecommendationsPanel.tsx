/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  CheckCircle, 
  AlertCircle, 
  Users, 
  Briefcase, 
  Building2, 
  Tractor,
  ArrowRight,
  ShieldAlert
} from 'lucide-react';
import { Recommendation } from '../types/agriculture';
import { CATEGORY_META } from '../data/agriRules';

interface RecommendationsPanelProps {
  recommendations: Recommendation[];
}

export const RecommendationsPanel: React.FC<RecommendationsPanelProps> = ({ recommendations }) => {
  const [filterTarget, setFilterTarget] = useState<string>('all');

  const filtered = recommendations.filter(
    r => filterTarget === 'all' || r.target === filterTarget
  );

  const getTargetIcon = (target: string) => {
    switch (target) {
      case 'farmer':
        return Tractor;
      case 'cooperative':
        return Building2;
      case 'trader':
        return Briefcase;
      default:
        return Users;
    }
  };

  const getTargetLabel = (target: string) => {
    switch (target) {
      case 'farmer':
        return 'Farmers & Growers';
      case 'cooperative':
        return 'Cooperatives & Warehouses';
      case 'trader':
        return 'Commodity Traders';
      default:
        return 'Agronomists & Regulators';
    }
  };

  const getPriorityStyle = (priority: 'high' | 'medium' | 'low') => {
    switch (priority) {
      case 'high':
        return {
          badge: 'High Priority',
          bg: 'bg-rose-50 text-rose-700 border-rose-200'
        };
      case 'medium':
        return {
          badge: 'Medium Priority',
          bg: 'bg-amber-50 text-amber-700 border-amber-200'
        };
      default:
        return {
          badge: 'Standard Protocol',
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200'
        };
    }
  };

  return (
    <section id="recommendations-section" className="py-8 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              Decision Support
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
              Actionable Agricultural Recommendations
            </h2>
          </div>

          {/* Stakeholder Filter Segmented Control */}
          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              onClick={() => setFilterTarget('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                filterTarget === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Stakeholders
            </button>
            <button
              onClick={() => setFilterTarget('farmer')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                filterTarget === 'farmer'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Farmers
            </button>
            <button
              onClick={() => setFilterTarget('cooperative')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                filterTarget === 'cooperative'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Cooperatives
            </button>
            <button
              onClick={() => setFilterTarget('trader')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                filterTarget === 'trader'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Traders
            </button>
            <button
              onClick={() => setFilterTarget('policymaker')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                filterTarget === 'policymaker'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Policy
            </button>
          </div>
        </div>

        {/* Recommendations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((rec) => {
            const Icon = getTargetIcon(rec.target);
            const priorityInfo = getPriorityStyle(rec.priority);
            const meta = CATEGORY_META[rec.category];

            return (
              <div 
                key={rec.id}
                className="bg-slate-50/60 rounded-xl border border-slate-200 p-5 flex flex-col justify-between hover:border-slate-300 transition-all shadow-2xs"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                      <Icon className="w-4 h-4 text-emerald-600" />
                      <span>{getTargetLabel(rec.target)}</span>
                    </div>

                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${priorityInfo.bg}`}>
                      {priorityInfo.badge}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 mb-2 leading-snug">
                    {rec.title}
                  </h3>

                  <p className="text-xs text-slate-800 leading-relaxed font-medium bg-white p-3 rounded-lg border border-slate-200/80 mb-3">
                    {rec.action}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 leading-normal">
                  <span className="font-semibold text-slate-700">Agronomic Rationale: </span>
                  {rec.rationale}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
