/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  BarChart2, 
  Wheat, 
  MapPin, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle,
  FileCheck2
} from 'lucide-react';
import { CategoryBreakdownScore, CommodityMention, RegionMention } from '../types/agriculture';
import { CATEGORY_META } from '../data/agriRules';

interface CategoryBreakdownProps {
  categories: CategoryBreakdownScore[];
  commodities: CommodityMention[];
  regions: RegionMention[];
  executiveSummary: string;
}

export const CategoryBreakdown: React.FC<CategoryBreakdownProps> = ({
  categories,
  commodities,
  regions,
  executiveSummary
}) => {
  return (
    <section className="py-8 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Executive Summary Callout */}
        <div className="bg-slate-50 rounded-xl border border-slate-200 p-5 mb-8">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-2">
            <FileCheck2 className="w-4 h-4 text-emerald-600" />
            <span>Executive Synthesis & Agronomic Posture</span>
          </div>
          <p className="text-sm text-slate-800 leading-relaxed font-sans">
            {executiveSummary}
          </p>
        </div>

        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <div className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              Dimensional Distribution
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
              Agricultural Thematic Breakdown & Entity Extraction
            </h2>
          </div>
          <div className="text-xs text-slate-500">
            Categorical intensity and identified commodities & geographic corridors
          </div>
        </div>

        {/* 2-Column Split: Thematic Categories on Left, Commodities & Regions on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left: 6 Thematic Dimensions */}
          <div className="lg:col-span-7 bg-slate-50/50 rounded-xl border border-slate-200 p-5">
            <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-emerald-600" />
              <span>Category Keyword Intensity & Sentiment</span>
            </h3>

            <div className="space-y-4">
              {categories.map((cat) => {
                const meta = CATEGORY_META[cat.category];
                return (
                  <div key={cat.category} className="bg-white rounded-lg border border-slate-200 p-3.5">
                    <div className="flex items-center justify-between gap-4 mb-1.5">
                      <div className="flex items-center gap-2">
                        <span 
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: meta.color }}
                        />
                        <span className="text-xs font-bold text-slate-900">
                          {cat.label}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-xs text-slate-600 font-mono">
                        <span>{cat.count} keywords</span>
                        <span aria-hidden="true">·</span>
                        <span className={`font-semibold ${
                          cat.sentimentScore > 0 ? 'text-emerald-700' :
                          cat.sentimentScore < 0 ? 'text-rose-700' : 'text-slate-500'
                        }`}>
                          {cat.sentimentScore > 0 ? `+${cat.sentimentScore}` : cat.sentimentScore} Net
                        </span>
                      </div>
                    </div>

                    {/* Progress track */}
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all duration-700"
                        style={{ 
                          width: `${cat.intensity}%`,
                          backgroundColor: meta.color
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Extracted Commodities & Regions */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Extracted Commodities Card */}
            <div className="bg-slate-50/50 rounded-xl border border-slate-200 p-5">
              <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                <Wheat className="w-4 h-4 text-amber-600" />
                <span>Detected Commodities</span>
              </h3>

              {commodities.length > 0 ? (
                <div className="space-y-2">
                  {commodities.map((item) => (
                    <div 
                      key={item.commodity}
                      className="bg-white rounded-lg border border-slate-200 p-2.5 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900">
                          {item.commodity}
                        </span>
                        <span className="text-slate-500 font-mono">
                          ({item.count} mentions)
                        </span>
                      </div>

                      <div className="flex items-center gap-1 font-medium">
                        {item.sentiment === 'bullish' ? (
                          <span className="text-emerald-700 flex items-center gap-1">
                            <TrendingUp className="w-3.5 h-3.5" /> Bullish Price
                          </span>
                        ) : item.sentiment === 'bearish' ? (
                          <span className="text-rose-700 flex items-center gap-1">
                            <TrendingDown className="w-3.5 h-3.5" /> Bearish Glut
                          </span>
                        ) : (
                          <span className="text-slate-500">
                            Neutral Context
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-slate-500 bg-white p-3 rounded-lg border border-slate-200">
                  No specific named agricultural crop commodities recognized in the text.
                </div>
              )}
            </div>

            {/* Extracted Geographic Zones Card */}
            <div className="bg-slate-50/50 rounded-xl border border-slate-200 p-5">
              <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span>Geographic Corridors</span>
              </h3>

              {regions.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {regions.map((reg) => (
                    <div 
                      key={reg.region}
                      className="bg-white rounded-md border border-slate-200 px-3 py-1.5 text-xs text-slate-800 flex items-center gap-1.5"
                    >
                      <MapPin className="w-3 h-3 text-slate-500" />
                      <span className="font-medium">{reg.region}</span>
                      <span className="text-slate-500 font-mono text-[11px]">({reg.count})</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-slate-500 bg-white p-3 rounded-lg border border-slate-200">
                  Global / Unspecified agricultural territory.
                </div>
              )}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
