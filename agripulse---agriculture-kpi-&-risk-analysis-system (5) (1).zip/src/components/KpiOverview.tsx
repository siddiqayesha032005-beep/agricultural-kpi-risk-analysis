/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Sprout, 
  Coins, 
  Fuel, 
  Award,
  HelpCircle
} from 'lucide-react';
import { AgriKPIs } from '../types/agriculture';

interface KpiOverviewProps {
  kpis: AgriKPIs;
}

export const KpiOverview: React.FC<KpiOverviewProps> = ({ kpis }) => {
  const getYieldStatus = (val: number) => {
    if (val >= 70) return { label: 'Bumper Potential', color: 'text-emerald-700' };
    if (val >= 50) return { label: 'Moderate Yield', color: 'text-slate-700' };
    if (val >= 35) return { label: 'Deficit Risk', color: 'text-amber-700' };
    return { label: 'Severe Stress', color: 'text-rose-700' };
  };

  const getMomentumStatus = (val: number) => {
    if (val > 25) return { label: 'Bullish Momentum', icon: TrendingUp, color: 'text-emerald-700' };
    if (val < -25) return { label: 'Bearish Friction', icon: TrendingDown, color: 'text-rose-700' };
    return { label: 'Neutral / Rangebound', icon: Activity, color: 'text-slate-600' };
  };

  const getInputPressureStatus = (val: number) => {
    if (val >= 70) return { label: 'Severe Margin Squeeze', color: 'text-rose-700' };
    if (val >= 45) return { label: 'Elevated Costs', color: 'text-amber-700' };
    return { label: 'Stable Input Costs', color: 'text-emerald-700' };
  };

  const getOpportunityStatus = (val: number) => {
    if (val >= 60) return { label: 'High Grant & Subsidy Support', color: 'text-teal-700' };
    if (val >= 35) return { label: 'Moderate Programs', color: 'text-slate-700' };
    return { label: 'Limited Incentives', color: 'text-slate-500' };
  };

  const yieldInfo = getYieldStatus(kpis.yieldSentimentIndex);
  const momentumInfo = getMomentumStatus(kpis.marketPriceMomentum);
  const inputInfo = getInputPressureStatus(kpis.inputCostPressureIndex);
  const oppInfo = getOpportunityStatus(kpis.opportunityIndex);
  const MomentumIcon = momentumInfo.icon;

  return (
    <section id="kpi-section" className="py-8 bg-slate-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <div className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              Executive Scorecard
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
              Agricultural Key Performance Indicators (KPIs)
            </h2>
          </div>
          <div className="text-xs text-slate-500">
            Synthesized from extracted agronomic, commercial, and financial signals
          </div>
        </div>

        {/* 5-Column KPI Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          
          {/* 1. Yield Sentiment Index */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 transition-all hover:border-slate-300 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-medium">Yield Sentiment</span>
              <Sprout className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
                {kpis.yieldSentimentIndex}
              </span>
              <span className="text-xs text-slate-500">/ 100</span>
            </div>
            
            {/* Progress bar */}
            <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2.5 overflow-hidden">
              <div 
                className={`h-full rounded-full ${
                  kpis.yieldSentimentIndex >= 65 ? 'bg-emerald-600' :
                  kpis.yieldSentimentIndex >= 45 ? 'bg-amber-500' : 'bg-rose-600'
                }`}
                style={{ width: `${kpis.yieldSentimentIndex}%` }}
              />
            </div>
            
            <div className="flex items-center justify-between mt-3 text-xs">
              <span className={`font-semibold ${yieldInfo.color}`}>
                {yieldInfo.label}
              </span>
              <span className="text-slate-500 text-[11px]">
                {kpis.yieldSentimentIndex >= 50 ? '+Above baseline' : '-Below baseline'}
              </span>
            </div>
          </div>

          {/* 2. Market Price Momentum */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 transition-all hover:border-slate-300 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-medium">Price Momentum</span>
              <Coins className="w-4 h-4 text-blue-600" />
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
                {kpis.marketPriceMomentum > 0 ? `+${kpis.marketPriceMomentum}` : kpis.marketPriceMomentum}
              </span>
              <span className="text-xs text-slate-500">pts</span>
            </div>

            {/* Bi-directional track */}
            <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2.5 relative overflow-hidden">
              <div 
                className={`h-full ${kpis.marketPriceMomentum >= 0 ? 'bg-blue-600' : 'bg-rose-500'}`}
                style={{ 
                  width: `${Math.min(100, Math.abs(kpis.marketPriceMomentum))}%`,
                  marginLeft: kpis.marketPriceMomentum < 0 ? 'auto' : 0
                }}
              />
            </div>

            <div className="flex items-center justify-between mt-3 text-xs">
              <span className={`font-semibold flex items-center gap-1 ${momentumInfo.color}`}>
                <MomentumIcon className="w-3.5 h-3.5" />
                {momentumInfo.label}
              </span>
              <span className="text-slate-500 text-[11px]">
                {kpis.marketPriceMomentum > 0 ? 'Inflationary' : 'Deflationary'}
              </span>
            </div>
          </div>

          {/* 3. Production Health Score */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 transition-all hover:border-slate-300 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-medium">Production Health</span>
              <Activity className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
                {kpis.productionHealthScore}
              </span>
              <span className="text-xs text-slate-500">%</span>
            </div>

            <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2.5 overflow-hidden">
              <div 
                className="h-full bg-emerald-600 rounded-full"
                style={{ width: `${kpis.productionHealthScore}%` }}
              />
            </div>

            <div className="flex items-center justify-between mt-3 text-xs">
              <span className="font-semibold text-slate-800">
                {kpis.productionHealthScore >= 60 ? 'Healthy Operations' : 'Strained Canopy'}
              </span>
              <span className="text-slate-500 text-[11px]">
                Favorable ratio
              </span>
            </div>
          </div>

          {/* 4. Input Cost Pressure Index */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 transition-all hover:border-slate-300 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-medium">Input Cost Pressure</span>
              <Fuel className="w-4 h-4 text-amber-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
                {kpis.inputCostPressureIndex}
              </span>
              <span className="text-xs text-slate-500">/ 100</span>
            </div>

            <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2.5 overflow-hidden">
              <div 
                className={`h-full rounded-full ${
                  kpis.inputCostPressureIndex >= 65 ? 'bg-rose-600' :
                  kpis.inputCostPressureIndex >= 40 ? 'bg-amber-500' : 'bg-emerald-600'
                }`}
                style={{ width: `${kpis.inputCostPressureIndex}%` }}
              />
            </div>

            <div className="flex items-center justify-between mt-3 text-xs">
              <span className={`font-semibold ${inputInfo.color}`}>
                {inputInfo.label}
              </span>
              <span className="text-slate-500 text-[11px]">
                Fertilizer/Fuel
              </span>
            </div>
          </div>

          {/* 5. Strategic Opportunity Index */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 transition-all hover:border-slate-300 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-medium">Opportunity Index</span>
              <Award className="w-4 h-4 text-teal-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
                {kpis.opportunityIndex}
              </span>
              <span className="text-xs text-slate-500">/ 100</span>
            </div>

            <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2.5 overflow-hidden">
              <div 
                className="h-full bg-teal-600 rounded-full"
                style={{ width: `${kpis.opportunityIndex}%` }}
              />
            </div>

            <div className="flex items-center justify-between mt-3 text-xs">
              <span className={`font-semibold ${oppInfo.color}`}>
                {oppInfo.label}
              </span>
              <span className="text-slate-500 text-[11px]">
                Grants & Subsidies
              </span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
