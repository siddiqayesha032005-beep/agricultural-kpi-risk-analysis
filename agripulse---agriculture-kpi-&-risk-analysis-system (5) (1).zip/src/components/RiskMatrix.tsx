/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Grid, 
  AlertCircle, 
  CheckCircle2, 
  HelpCircle, 
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { RiskMatrixItem, RiskLevel } from '../types/agriculture';
import { CATEGORY_META } from '../data/agriRules';

interface RiskMatrixProps {
  items: RiskMatrixItem[];
}

export const RiskMatrix: React.FC<RiskMatrixProps> = ({ items }) => {
  const [selectedRiskId, setSelectedRiskId] = useState<string>(items[0]?.id || '');

  const selectedItem = items.find(i => i.id === selectedRiskId) || items[0];

  // Likelihood columns (1 to 5)
  const likelihoodCols = [
    { num: 1, label: '1 - Rare' },
    { num: 2, label: '2 - Unlikely' },
    { num: 3, label: '3 - Moderate' },
    { num: 4, label: '4 - Likely' },
    { num: 5, label: '5 - Almost Certain' }
  ];

  // Impact rows (5 down to 1)
  const impactRows = [
    { num: 5, label: '5 - Catastrophic' },
    { num: 4, label: '4 - Major' },
    { num: 3, label: '3 - Moderate' },
    { num: 2, label: '2 - Minor' },
    { num: 1, label: '1 - Negligible' }
  ];

  // Cell risk level classification for styling
  const getCellRiskClass = (likelihood: number, impact: number) => {
    const score = likelihood * impact;
    if (score >= 16) return 'bg-rose-100/70 border-rose-200 text-rose-900';
    if (score >= 10) return 'bg-orange-100/60 border-orange-200 text-orange-900';
    if (score >= 5) return 'bg-amber-100/50 border-amber-200 text-amber-900';
    return 'bg-emerald-50/50 border-emerald-100 text-emerald-900';
  };

  return (
    <section id="risk-matrix-section" className="py-8 bg-slate-50/50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <div className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              Qualitative & Quantitative Heatmap
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
              Agricultural Risk Matrix (Likelihood vs Impact)
            </h2>
          </div>
          <div className="text-xs text-slate-500">
            Click any plotted risk node to inspect extracted sentence evidence and prescribed mitigations
          </div>
        </div>

        {/* 2-Column Layout: 5x5 Matrix on Left/Center, Evidence Panel on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Matrix Grid Container */}
          <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-2xs overflow-x-auto">
            
            {/* Top Likelihood Axis Header */}
            <div className="text-center font-bold text-xs text-slate-700 uppercase tracking-wider mb-2">
              Likelihood Axis
            </div>

            <div className="min-w-[540px]">
              {/* Columns labels */}
              <div className="grid grid-cols-6 gap-1 mb-1">
                <div className="text-[11px] font-semibold text-slate-500 uppercase flex items-center justify-center">
                  Impact \ Likelihood
                </div>
                {likelihoodCols.map(col => (
                  <div key={col.num} className="text-center text-[11px] font-semibold text-slate-600 bg-slate-100 py-1 rounded">
                    {col.label}
                  </div>
                ))}
              </div>

              {/* Matrix Rows */}
              {impactRows.map(row => (
                <div key={row.num} className="grid grid-cols-6 gap-1 mb-1">
                  {/* Row Label (Y-Axis) */}
                  <div className="flex items-center justify-end pr-2 text-[11px] font-semibold text-slate-600 bg-slate-100 rounded px-1">
                    {row.label}
                  </div>

                  {/* 5 Likelihood Cells */}
                  {likelihoodCols.map(col => {
                    const cellRisks = items.filter(
                      i => i.likelihood === col.num && i.impact === row.num
                    );
                    const cellClass = getCellRiskClass(col.num, row.num);

                    return (
                      <div
                        key={`${row.num}-${col.num}`}
                        className={`min-h-[56px] p-1 rounded border flex flex-col gap-1 transition-all ${cellClass}`}
                      >
                        {cellRisks.map(risk => {
                          const isSelected = selectedRiskId === risk.id;
                          return (
                            <button
                              key={risk.id}
                              onClick={() => setSelectedRiskId(risk.id)}
                              className={`w-full text-left p-1 text-[11px] rounded font-medium truncate transition-all shadow-xs ${
                                isSelected
                                  ? 'bg-slate-900 text-white ring-2 ring-slate-900 ring-offset-1'
                                  : 'bg-white/90 hover:bg-white text-slate-900 border border-slate-300'
                              }`}
                              title={risk.title}
                            >
                              <div className="truncate font-semibold">{risk.title}</div>
                            </button>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>

            {/* Matrix Legend */}
            <div className="flex flex-wrap items-center justify-between gap-4 mt-4 pt-3 border-t border-slate-100 text-xs text-slate-600">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-emerald-100 border border-emerald-300 inline-block" />
                  <span>Low Risk (1-4)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-amber-100 border border-amber-300 inline-block" />
                  <span>Moderate (5-9)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-orange-100 border border-orange-300 inline-block" />
                  <span>High (10-15)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-rose-100 border border-rose-300 inline-block" />
                  <span>Critical (16-25)</span>
                </div>
              </div>

              <div className="text-[11px] text-slate-500 font-mono">
                Total Plotted Threats: {items.length}
              </div>
            </div>
          </div>

          {/* Right: Selected Risk Evidence & Agronomic Mitigation Card */}
          <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            {selectedItem ? (
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Threat Details
                  </span>
                  <span 
                    className="text-xs font-semibold px-2 py-0.5 rounded"
                    style={{
                      backgroundColor: `${CATEGORY_META[selectedItem.category]?.color}15`,
                      color: CATEGORY_META[selectedItem.category]?.color
                    }}
                  >
                    {CATEGORY_META[selectedItem.category]?.label || selectedItem.category}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-slate-900 mb-2">
                  {selectedItem.title}
                </h3>

                {/* Score breakdown metrics */}
                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-100 mb-4 text-center">
                  <div>
                    <div className="text-[11px] text-slate-500">Likelihood</div>
                    <div className="text-sm font-bold text-slate-800 font-mono">{selectedItem.likelihood} / 5</div>
                  </div>
                  <div>
                    <div className="text-[11px] text-slate-500">Impact</div>
                    <div className="text-sm font-bold text-slate-800 font-mono">{selectedItem.impact} / 5</div>
                  </div>
                  <div>
                    <div className="text-[11px] text-slate-500">Risk Score</div>
                    <div className="text-sm font-bold text-rose-700 font-mono">{selectedItem.riskScore} / 25</div>
                  </div>
                </div>

                {/* Evidence snippet */}
                <div className="mb-4">
                  <div className="text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                    <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                    Textual Evidence in Article:
                  </div>
                  <blockquote className="text-xs text-slate-700 bg-amber-50/60 border-l-2 border-amber-500 p-2.5 rounded-r italic leading-relaxed">
                    "{selectedItem.evidence}"
                  </blockquote>
                </div>

                {/* Agronomic Mitigation */}
                <div>
                  <div className="text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    Actionable Mitigation Strategy:
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed bg-emerald-50/50 p-2.5 rounded border border-emerald-100">
                    {selectedItem.mitigation}
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-slate-500 text-xs">
                Select a risk node from the matrix to view evidence and mitigation steps.
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
};
