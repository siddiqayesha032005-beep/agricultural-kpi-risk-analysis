/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  AnalysisResult,
  KeywordRule,
  MatchedKeyword,
  AgriKPIs,
  AgriKRIs,
  CategoryBreakdownScore,
  CommodityMention,
  RegionMention,
  RiskMatrixItem,
  Recommendation,
  RiskLevel,
  AgriCategory
} from '../types/agriculture';
import { DEFAULT_RULES, COMMODITY_DICTIONARY, REGION_DICTIONARY, CATEGORY_META } from '../data/agriRules';

// Split text into readable sentences
export function splitIntoSentences(text: string): string[] {
  if (!text) return [];
  return text
    .replace(/([.?!])\s+(?=[A-Z0-9])/g, "$1|")
    .split("|")
    .map(s => s.trim())
    .filter(s => s.length > 5);
}

// Check for negation prefixes within 4 words of the match
function isNegated(sentence: string, matchIndex: number): boolean {
  const preceding = sentence.slice(Math.max(0, matchIndex - 35), matchIndex).toLowerCase();
  const negationWords = ['no ', 'not ', 'never ', 'free of ', 'eradicated ', 'without ', 'none '];
  return negationWords.some(neg => preceding.includes(neg));
}

export function analyzeAgriculturalText(
  text: string,
  sourceTitle: string = 'Agricultural Field Report',
  sourceType: string = 'General News',
  customRules: KeywordRule[] = DEFAULT_RULES
): AnalysisResult {
  const sentences = splitIntoSentences(text);
  const words = text.trim().split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const sentenceCount = sentences.length;

  // 1. Keyword Matching
  const matchedMap = new Map<string, MatchedKeyword>();
  const lowerText = text.toLowerCase();

  customRules.forEach(rule => {
    const kwLower = rule.keyword.toLowerCase();
    let searchFrom = 0;
    let count = 0;
    const matchedSentences: string[] = [];

    while (searchFrom < lowerText.length) {
      const idx = lowerText.indexOf(kwLower, searchFrom);
      if (idx === -1) break;

      // Find which sentence contains this match
      let currentSentence = '';
      let charAcc = 0;
      for (const sent of sentences) {
        if (charAcc + sent.length >= idx) {
          currentSentence = sent;
          break;
        }
        charAcc += sent.length;
      }

      const negated = currentSentence ? isNegated(currentSentence, idx - charAcc) : false;

      // Only count if not directly negated
      if (!negated) {
        count++;
        if (currentSentence && !matchedSentences.includes(currentSentence)) {
          matchedSentences.push(currentSentence);
        }
      }

      searchFrom = idx + kwLower.length;
    }

    if (count > 0) {
      matchedMap.set(rule.keyword, {
        keyword: rule.keyword,
        category: rule.category,
        count,
        weight: rule.weight,
        sentiment: rule.sentiment,
        impact: rule.defaultImpact,
        likelihood: Math.min(5, rule.defaultLikelihood + (count > 1 ? 1 : 0)),
        matchedSentences
      });
    }
  });

  const matchedKeywords = Array.from(matchedMap.values()).sort((a, b) => (b.weight * b.count) - (a.weight * a.count));

  // 2. Extract Commodities
  const commodities: CommodityMention[] = [];
  COMMODITY_DICTIONARY.forEach(comm => {
    let count = 0;
    const contexts: string[] = [];
    comm.patterns.forEach(pat => {
      const regex = new RegExp(`\\b${pat}\\b`, 'gi');
      const matches = text.match(regex);
      if (matches) {
        count += matches.length;
        sentences.forEach(s => {
          if (regex.test(s) && contexts.length < 3 && !contexts.includes(s)) {
            contexts.push(s);
          }
        });
      }
    });

    if (count > 0) {
      // Determine sentiment context for commodity
      const textChunk = contexts.join(' ').toLowerCase();
      let sentiment: 'bullish' | 'bearish' | 'neutral' = 'neutral';
      if (/price surge|price hike|record price|rally|bullish|demand/i.test(textChunk)) {
        sentiment = 'bullish';
      } else if (/price slump|crash|oversupply|glut|bearish/i.test(textChunk)) {
        sentiment = 'bearish';
      }

      commodities.push({
        commodity: comm.name,
        count,
        sentiment,
        contexts
      });
    }
  });
  commodities.sort((a, b) => b.count - a.count);

  // 3. Extract Regions
  const regions: RegionMention[] = [];
  REGION_DICTIONARY.forEach(reg => {
    let count = 0;
    reg.patterns.forEach(pat => {
      const regex = new RegExp(`\\b${pat}\\b`, 'gi');
      const matches = text.match(regex);
      if (matches) count += matches.length;
    });
    if (count > 0) {
      regions.push({ region: reg.name, count });
    }
  });
  regions.sort((a, b) => b.count - a.count);

  // 4. Category Scoring & Breakdown
  const categories: AgriCategory[] = [
    'crop_conditions',
    'market_trends',
    'weather_risks',
    'pest_disease',
    'supply_chain',
    'opportunities'
  ];

  const categoryBreakdown: CategoryBreakdownScore[] = categories.map(cat => {
    const kws = matchedKeywords.filter(k => k.category === cat);
    const count = kws.reduce((acc, k) => acc + k.count, 0);
    const rawScore = kws.reduce((acc, k) => acc + (k.weight * k.count), 0);
    
    // Normalize intensity (0 - 100)
    const intensity = Math.min(100, Math.round(rawScore * 7));

    // Calculate category sentiment (-1 to +1)
    let posWeight = 0;
    let negWeight = 0;
    kws.forEach(k => {
      if (k.sentiment === 'positive') posWeight += k.weight * k.count;
      if (k.sentiment === 'negative') negWeight += k.weight * k.count;
    });
    const totalWeight = posWeight + negWeight;
    const sentimentScore = totalWeight > 0 ? (posWeight - negWeight) / totalWeight : 0;

    return {
      category: cat,
      label: CATEGORY_META[cat].label,
      count,
      intensity,
      sentimentScore: Math.round(sentimentScore * 100) / 100
    };
  });

  // 5. Compute Key Risk Indicators (KRIs)
  const weatherKws = matchedKeywords.filter(k => k.category === 'weather_risks' && k.sentiment === 'negative');
  const pestKws = matchedKeywords.filter(k => k.category === 'pest_disease' && k.sentiment === 'negative');
  const supplyKws = matchedKeywords.filter(k => k.category === 'supply_chain' && k.sentiment === 'negative');
  const marketRiskKws = matchedKeywords.filter(k => k.category === 'market_trends' && k.sentiment === 'negative');

  const calcKriScore = (kws: MatchedKeyword[]) => {
    if (kws.length === 0) return 12; // Nominal baseline
    const weightedSum = kws.reduce((acc, k) => acc + (k.weight * k.count * 6), 0);
    return Math.min(98, Math.max(15, Math.round(weightedSum)));
  };

  const weatherVulnerabilityKRI = calcKriScore(weatherKws);
  const biosecurityHazardKRI = calcKriScore(pestKws);
  const supplyChainFrictionKRI = calcKriScore(supplyKws);
  const marketVolatilityKRI = calcKriScore(marketRiskKws);

  // Composite Risk Score
  const rawComposite = (
    weatherVulnerabilityKRI * 0.30 +
    biosecurityHazardKRI * 0.25 +
    supplyChainFrictionKRI * 0.25 +
    marketVolatilityKRI * 0.20
  );
  const compositeRiskScore = Math.min(99, Math.max(10, Math.round(rawComposite)));

  let compositeRiskLevel: RiskLevel = 'low';
  if (compositeRiskScore >= 75) {
    compositeRiskLevel = 'critical';
  } else if (compositeRiskScore >= 55) {
    compositeRiskLevel = 'high';
  } else if (compositeRiskScore >= 32) {
    compositeRiskLevel = 'moderate';
  } else {
    compositeRiskLevel = 'low';
  }

  const kris: AgriKRIs = {
    compositeRiskScore,
    compositeRiskLevel,
    weatherVulnerabilityKRI,
    biosecurityHazardKRI,
    supplyChainFrictionKRI,
    marketVolatilityKRI
  };

  // 6. Compute Key Performance Indicators (KPIs)
  // Yield Sentiment Index (0 - 100)
  const cropPos = matchedKeywords.filter(k => k.category === 'crop_conditions' && k.sentiment === 'positive');
  const cropNeg = matchedKeywords.filter(k => k.category === 'crop_conditions' && k.sentiment === 'negative');
  const cropPosScore = cropPos.reduce((acc, k) => acc + k.weight * k.count, 0);
  const cropNegScore = cropNeg.reduce((acc, k) => acc + k.weight * k.count, 0);
  const weatherDroughtPenalty = weatherVulnerabilityKRI > 50 ? (weatherVulnerabilityKRI - 50) * 0.35 : 0;
  
  let yieldSentiment = 50 + (cropPosScore * 8) - (cropNegScore * 9) - weatherDroughtPenalty;
  yieldSentiment = Math.min(96, Math.max(10, Math.round(yieldSentiment)));

  // Market Price Momentum (-100 to +100)
  const marketBullish = matchedKeywords.filter(k => 
    (k.category === 'market_trends' && (k.keyword.includes('surge') || k.keyword.includes('hike') || k.keyword.includes('bullish') || k.keyword.includes('record') || k.keyword.includes('rally')))
  ).reduce((acc, k) => acc + k.weight * k.count, 0);

  const marketBearish = matchedKeywords.filter(k => 
    (k.category === 'market_trends' && (k.keyword.includes('slump') || k.keyword.includes('crash') || k.keyword.includes('oversupply') || k.keyword.includes('glut') || k.keyword.includes('curbs') || k.keyword.includes('ban')))
  ).reduce((acc, k) => acc + k.weight * k.count, 0);

  let marketMomentum = (marketBullish * 18) - (marketBearish * 18);
  marketMomentum = Math.min(95, Math.max(-95, Math.round(marketMomentum)));

  // Opportunity Index (0 - 100)
  const oppKws = matchedKeywords.filter(k => k.category === 'opportunities');
  const oppScore = oppKws.reduce((acc, k) => acc + k.weight * k.count, 0);
  const opportunityIndex = Math.min(95, Math.max(15, Math.round(15 + oppScore * 10)));

  // Input Cost Pressure Index (0 - 100)
  const inputKws = matchedKeywords.filter(k => 
    k.keyword.includes('fertilizer') || 
    k.keyword.includes('urea') || 
    k.keyword.includes('diesel') || 
    k.keyword.includes('freight') || 
    k.keyword.includes('labor') ||
    k.keyword.includes('tariff')
  );
  const inputScore = inputKws.reduce((acc, k) => acc + k.weight * k.count, 0);
  const inputCostPressureIndex = Math.min(98, Math.max(14, Math.round(20 + inputScore * 12)));

  // Production Health Score (0 - 100)
  const overallPos = matchedKeywords.filter(k => k.sentiment === 'positive').reduce((acc, k) => acc + k.weight * k.count, 0);
  const overallNeg = matchedKeywords.filter(k => k.sentiment === 'negative').reduce((acc, k) => acc + k.weight * k.count, 0);
  let healthScore = Math.round(((overallPos + 5) / (overallPos + overallNeg + 10)) * 100);
  healthScore = Math.min(95, Math.max(12, healthScore));

  const kpis: AgriKPIs = {
    yieldSentimentIndex: yieldSentiment,
    marketPriceMomentum: marketMomentum,
    opportunityIndex,
    inputCostPressureIndex,
    productionHealthScore: healthScore
  };

  // 7. Risk Matrix Generation (5x5 Grid)
  const riskMatrix: RiskMatrixItem[] = [];
  const negativeKws = matchedKeywords.filter(k => k.sentiment === 'negative');

  negativeKws.slice(0, 8).forEach((k, idx) => {
    const rawScore = k.likelihood * k.impact;
    let level: RiskLevel = 'low';
    if (rawScore >= 16) level = 'critical';
    else if (rawScore >= 10) level = 'high';
    else if (rawScore >= 6) level = 'moderate';

    // Tailored mitigation suggestions
    let mitigation = 'Implement field monitoring and establish backup operational reserves.';
    if (k.category === 'weather_risks') {
      mitigation = 'Activate moisture retention mulch, test deficit irrigation schedules, and review multi-peril crop insurance.';
    } else if (k.category === 'pest_disease') {
      mitigation = 'Deploy pheromone traps, quarantine infected border rows, and prepare targeted biological control agents.';
    } else if (k.category === 'supply_chain') {
      mitigation = 'Secure early bulk input contracts, diversify freight carriers, and assess on-farm temporary storage buffers.';
    } else if (k.category === 'market_trends') {
      mitigation = 'Hedge price downside via forward marketing contracts and review export tariff exemptions.';
    }

    riskMatrix.push({
      id: `risk-${idx}`,
      title: k.keyword.charAt(0).toUpperCase() + k.keyword.slice(1),
      category: k.category,
      likelihood: k.likelihood,
      impact: k.impact,
      riskScore: rawScore,
      level,
      evidence: k.matchedSentences[0] || `Detected indicator: "${k.keyword}" (Frequency: ${k.count})`,
      mitigation
    });
  });

  // If no negative keywords detected, supply default baseline point
  if (riskMatrix.length === 0) {
    riskMatrix.push({
      id: 'risk-baseline',
      title: 'Standard Agronomic Variability',
      category: 'crop_conditions',
      likelihood: 2,
      impact: 2,
      riskScore: 4,
      level: 'low',
      evidence: 'No acute negative risk keywords detected in the submitted agricultural text.',
      mitigation: 'Continue regular pest scouting and routine soil moisture monitoring.'
    });
  }

  // 8. Generate Actionable Strategic Recommendations
  const recommendations: Recommendation[] = [];

  // Farmer recommendations
  if (weatherVulnerabilityKRI >= 50) {
    recommendations.push({
      id: 'rec-1',
      target: 'farmer',
      title: 'Drought & Extreme Weather Resilience',
      action: 'Shift to moisture-conserving tillage and schedule irrigation during low-evaporation evening windows.',
      rationale: `Weather Vulnerability KRI is elevated at ${weatherVulnerabilityKRI}/100 with climatic stress indicators detected.`,
      priority: 'high',
      category: 'weather_risks'
    });
  }

  if (biosecurityHazardKRI >= 45) {
    recommendations.push({
      id: 'rec-2',
      target: 'farmer',
      title: 'Biosecurity Scouting & Preventative Barrier',
      action: 'Inspect field borders twice weekly for pest emergence and notify extension agents for localized IPM protocol.',
      rationale: `Pest & disease concerns identified with a Biosecurity Hazard index of ${biosecurityHazardKRI}/100.`,
      priority: 'high',
      category: 'pest_disease'
    });
  }

  // Cooperative recommendations
  if (supplyChainFrictionKRI >= 45 || inputCostPressureIndex >= 50) {
    recommendations.push({
      id: 'rec-3',
      target: 'cooperative',
      title: 'Collective Input Procurement & Storage Staging',
      action: 'Pool fertilizer and diesel purchasing orders across member farms to negotiate volume discounts and hedge supply bottlenecks.',
      rationale: `Input Cost Pressure is critical at ${inputCostPressureIndex}/100, impacting grower margins.`,
      priority: 'high',
      category: 'supply_chain'
    });
  }

  // Trader recommendations
  if (Math.abs(marketMomentum) >= 30) {
    const isBull = marketMomentum > 0;
    recommendations.push({
      id: 'rec-4',
      target: 'trader',
      title: isBull ? 'Bullish Futures Hedging & Forward Locking' : 'Bearish Protection & Basis Management',
      action: isBull 
        ? 'Lock in forward contracts for late-season deliveries before transport bottlenecks inflate basis premiums.'
        : 'Establish price floor option collars to protect against localized oversupply and falling farmgate cash bids.',
      rationale: `Market momentum is registering ${marketMomentum > 0 ? '+' : ''}${marketMomentum} with strong directional price pressures.`,
      priority: 'medium',
      category: 'market_trends'
    });
  }

  // Opportunity recommendation
  if (opportunityIndex >= 40) {
    recommendations.push({
      id: 'rec-5',
      target: 'policymaker',
      title: 'Accelerate Subsidy & Agritech Program Enrollment',
      action: 'Direct field staff to assist growers with grant applications for precision water sensors, solar rebates, and cover crops.',
      rationale: `Multiple strategic opportunities identified (Opportunity Index: ${opportunityIndex}/100).`,
      priority: 'medium',
      category: 'opportunities'
    });
  }

  // Ensure at least 3 recommendations always exist
  if (recommendations.length < 3) {
    recommendations.push({
      id: 'rec-generic',
      target: 'farmer',
      title: 'Continuous Agronomic Scouting',
      action: 'Conduct soil nutrient sampling and track local weather forecasts to optimize seasonal fertilizer top-dressing.',
      rationale: 'Baseline operational protocol to maintain crop vigor and optimize yield.',
      priority: 'low',
      category: 'crop_conditions'
    });
  }

  // 9. Executive Summary
  const topRisks = riskMatrix.filter(r => r.level === 'critical' || r.level === 'high').map(r => r.title);
  const topComms = commodities.map(c => c.commodity).slice(0, 3).join(', ') || 'General agricultural commodities';
  const topRegs = regions.map(r => r.region).slice(0, 2).join(' & ') || 'Global agricultural regions';

  const riskAssessmentText = compositeRiskLevel === 'critical' || compositeRiskLevel === 'high'
    ? `The intelligence signals severe agronomic and operational head-winds, dominated by ${topRisks.slice(0, 3).join(', ') || 'weather and logistics stress'}. Composite Agri-Risk is rated ${compositeRiskLevel.toUpperCase()} (${compositeRiskScore}/100).`
    : `The intelligence reflects manageable agricultural conditions with a ${compositeRiskLevel.toUpperCase()} Composite Agri-Risk rating (${compositeRiskScore}/100).`;

  const marketAssessmentText = marketMomentum > 20
    ? `Market pricing indicates bullish upward momentum (${marketMomentum > 0 ? '+' : ''}${marketMomentum}), driven by supply tightness and steady export interest.`
    : marketMomentum < -20
    ? `Market indicators point to bearish price friction (${marketMomentum}), influenced by localized oversupply or logistics congestion.`
    : `Market price momentum remains relatively balanced around baseline equilibrium (${marketMomentum}).`;

  const oppText = opportunityIndex > 45
    ? `Strong strategic counterweights exist: high opportunity score of ${opportunityIndex}/100 highlights available government subsidies, grants, and precision farming rebates.`
    : `Growers and agribusinesses should prioritize cost efficiency, as current strategic grants and subsidies are limited (${opportunityIndex}/100).`;

  const executiveSummary = `${riskAssessmentText} Focal commodities include ${topComms} across ${topRegs}. ${marketAssessmentText} ${oppText}`;

  return {
    id: `eval-${Date.now()}`,
    timestamp: new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }),
    sourceTitle,
    sourceType,
    wordCount,
    sentenceCount,
    kpis,
    kris,
    categoryBreakdown,
    matchedKeywords,
    commodities,
    regions,
    riskMatrix,
    recommendations,
    rawText: text,
    executiveSummary
  };
}
